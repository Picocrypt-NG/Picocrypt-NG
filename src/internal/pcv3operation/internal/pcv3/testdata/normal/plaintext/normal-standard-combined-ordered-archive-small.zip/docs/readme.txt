Extraction is admitted only after whole-volume authentication.
